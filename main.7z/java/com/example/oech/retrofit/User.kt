package com.example.oech.retrofit

data class User (
    val name:String,
    val phoneNumber:String,
    val email:String,
    val password:String
)