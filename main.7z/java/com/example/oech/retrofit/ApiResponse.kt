package com.example.oech.retrofit

data class ApiResponse(
    val success: Boolean,
    val message: String
)
